// Get references to the DOM elements
const welcomeContainer = document.getElementById('welcome-container');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const userlistContainer = document.getElementById('userlist-container');
const logoutButton = document.getElementById('logout-button');
const editUserForm = document.getElementById('edit-user-form');
const deleteUserModal = document.getElementById('delete-user-modal');
const chatContainer = document.getElementById('chat-container');
const documentlistContainer = document.getElementById('documentlist-container');
const uploadModal = document.getElementById('upload-modal');
const editDocumentModal = document.getElementById('edit-document-modal');
const deleteUploadModal = document.getElementById('delete-upload-modal');

// Local Storage Keys
const USERS_KEY = 'users';
const LOGGEDIN_USER_KEY = 'loggedInUser';
const UPLOADS_KEY = 'uploads';
const CHATS_KEY = 'chats';

// Global Variables
let loggedInUser = null;

// Load User Data from Local Storage
loadUserData();

// Handle Login Form Submission
loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const email = loginForm.email.value;
    const password = loginForm.password.value;

    const user = findUser(email, password);

    if (user) {
        // Login Successful
        loggedInUser = user;
        localStorage.setItem(LOGGEDIN_USER_KEY, JSON.stringify(user));
        showLoginSuccessPage();
    } else {
        // Login Failed
        alert("Wrong Email or Password");
    }
});

// Handle Register Form Submission
registerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const fullname = registerForm.fullname.value;
    const email = registerForm.email.value;
    const password = registerForm.password.value;
    const confirmPassword = registerForm.confirmPassword.value;

    if (password === confirmPassword) {
        const newUser = {
            id: generateUniqueId(),
            name: fullname,
            email: email,
            password: password
        };

        if (findUser(email) === null) {
            // New user added
            addUser(newUser);
            showRegisterSuccessPage();
        } else {
            // User already exists
            alert("User already exists");
        }
    } else {
        alert("Password and Confirm Password should match");
    }
});

// Function to find a user
function findUser(email, password) {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    for (const user of users) {
        if (user.email === email && (password ? user.password === password : true)) {
            return user;
        }
    }
    return null;
}

// Function to add a user
function addUser(user) {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    users.push(user);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// Function to display the Login Success page
function showLoginSuccessPage() {
    // Add code to redirect to LoginSuccess.html or display a success message
    window.location.href = 'LoginSuccess.html';
}

// Function to display the Register Success page
function showRegisterSuccessPage() {
    // Add code to redirect to RegisterSuccess.html or display a success message
    window.location.href = 'RegisterSuccess.html';
}

// Function to display the User List
function showUserList() {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');

    const userList = document.createElement('table');
    userList.innerHTML = `
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    `;

    const tbody = userList.querySelector('tbody');
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>
                <a href="EditUser.html?id=${user.id}">Edit</a> | 
                <a href="#" onclick="deleteUser(${user.id})">Delete</a>
            </td>
        `;
        tbody.appendChild(row);
    });

    userlistContainer.innerHTML = '';
    userlistContainer.appendChild(userList);
}

// Function to delete a user
function deleteUser(id) {
    if (confirm("Are you sure you want to delete this user?")) {
        const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
        const index = users.findIndex(user => user.id === id);
        if (index > -1) {
            users.splice(index, 1);
            localStorage.setItem(USERS_KEY, JSON.stringify(users));
            showUserList();
        }
    }
}

// Function to display the Logout page
function showLogoutPage() {
    localStorage.removeItem(LOGGEDIN_USER_KEY);
    loggedInUser = null;
    // Redirect to Logout.html or display a logout message
    window.location.href = 'Logout.html';
}

// Function to generate a unique ID
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2, 15);
}

// Function to load user data from local storage
function loadUserData() {
    loggedInUser = JSON.parse(localStorage.getItem(LOGGEDIN_USER_KEY));

    if (loggedInUser) {
        // User is logged in, show the user list
        showUserList();
    } else {
        // User is not logged in, show the welcome page
        showWelcomePage();
    }
}

// Function to display the Welcome page
function showWelcomePage() {
    // Add code to display the Welcome.html page or content
    window.location.href = 'Welcome.html';
}

// Event Listener for the Logout Button
logoutButton.addEventListener('click', showLogoutPage);

// Update the UI based on user login status
loadUserData();